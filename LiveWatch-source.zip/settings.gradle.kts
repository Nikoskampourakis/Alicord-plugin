rootProject.name = "AlicordLiveWatch"
include(":LiveWatch")
