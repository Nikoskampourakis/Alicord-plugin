# Alicord LiveWatch

Aliucord plugin. Tells you when a server's owner (or a live-announcement bot in the server) goes live on Twitch/YouTube,
rings the server icon like a YouTube live avatar, and opens a "Watch Room" (a virtual server page) with the stream,
chat, and voice. Watch together with a friend via an invite code.

## Build
1. Easiest: copy the `LiveWatch/` folder into your existing Aliucord plugins repo (next to your other plugins),
   add `include(":LiveWatch")` to its `settings.gradle.kts`, and run `./gradlew :LiveWatch:make`.
2. Or use this folder as its own repo (root files are the standard plugin-template ones; set your Discord id in
   `build.gradle.kts`) and run `./gradlew :LiveWatch:make`.
3. Copy `LiveWatch/build/outputs/LiveWatch.zip` into `Aliucord/plugins/` on the phone and restart Aliucord.

## Setup
* Settings -> Plugins -> LiveWatch: paste a Twitch Client ID + Secret (free, dev.twitch.tv/console). YouTube needs no key.
* Owners are only detected if their Twitch/YouTube connection is **visible on their Discord profile**.

## Use
* Tap a server with a live ring -> Watch Room. Player button switches Platform <-> Custom player.
* `/livewatch` hub (who is live, join, settings) · `/watchjoin code:` · `/watchinvite` (run inside any DM/group DM:
  that chat becomes the party chat + call).

## Where to look if Discord updates break something
Every Discord/Aliucord internal call is in `Bridge.kt`; the two patched methods are in `LiveWatch.kt`
(`WidgetGuildListAdapter.onBindViewHolder`, `StoreMessages.handleMessageCreate`).
`player.html` is the custom player source (already inlined into `PlayerHtml.kt`).
