import com.aliucord.gradle.AliucordExtension
import com.android.build.gradle.BaseExtension
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

// Standard Aliucord plugin-template root. If you already have a plugins repo, keep YOUR root
// files and just copy the LiveWatch/ folder into it.
buildscript {
    repositories {
        google()
        mavenCentral()
        maven("https://maven.aliucord.com/snapshots")
        maven("https://jitpack.io")
    }
    dependencies {
        classpath("com.android.tools.build:gradle:7.0.4")
        classpath("com.aliucord:gradle:main-SNAPSHOT")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.6.21")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven("https://maven.aliucord.com/snapshots")
        maven("https://jitpack.io")
    }
}

fun Project.aliucord(configuration: AliucordExtension.() -> Unit) =
    extensions.getByName<AliucordExtension>("aliucord").configuration()

fun Project.android(configuration: BaseExtension.() -> Unit) =
    extensions.getByName<BaseExtension>("android").configuration()

subprojects {
    apply(plugin = "com.android.library")
    apply(plugin = "com.aliucord.gradle")
    apply(plugin = "kotlin-android")

    aliucord {
        author("YourName", 0L)  // CHANGE to your Discord user ID          // <- put your Discord user id here
    }

    android {
        compileSdkVersion(30)
        defaultConfig {
            minSdk = 24
            targetSdk = 30
        }
        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_11
            targetCompatibility = JavaVersion.VERSION_11
        }
        tasks.withType<KotlinCompile> {
            kotlinOptions {
                jvmTarget = "11"
                freeCompilerArgs = freeCompilerArgs + "-Xno-call-assertions" + "-Xno-param-assertions" + "-Xno-receiver-assertions"
            }
        }
    }

    dependencies {
        val discord by configurations
        val compileOnly by configurations
        discord("com.discord:discord:aliucord-SNAPSHOT")
        compileOnly("com.aliucord:Aliucord:main-SNAPSHOT")
        compileOnly("androidx.appcompat:appcompat:1.4.0")
        compileOnly("com.google.android.material:material:1.4.0")
        compileOnly("androidx.constraintlayout:constraintlayout:2.1.2")
        compileOnly("androidx.recyclerview:recyclerview:1.2.1")
    }
}

task<Delete>("clean") { delete(rootProject.buildDir) }
