# Build LiveWatch for Aliucord

## One-shot (Codespaces / any Linux with enough RAM)

```bash
# 1. Install JDK 17 if needed
sudo apt-get update && sudo apt-get install -y openjdk-17-jdk unzip curl

# 2. Install Android command-line tools (once)
mkdir -p $HOME/android-sdk/cmdline-tools
cd /tmp
curl -fsSL -o cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip -q cmdtools.zip
mv cmdline-tools $HOME/android-sdk/cmdline-tools/latest
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
yes | sdkmanager --licenses
sdkmanager "platforms;android-30" "build-tools;30.0.3" "platform-tools"

# 3. Build the plugin
cd /path/to/this/folder   # the folder that contains settings.gradle.kts and LiveWatch/
echo "sdk.dir=$ANDROID_HOME" > local.properties
# optional: put your Discord ID in build.gradle.kts  author("Name", 123456789L)
./gradlew :LiveWatch:make --no-daemon
# or if no wrapper yet:
# gradle :LiveWatch:make --no-daemon   (needs Gradle 7.4+)
```

Output: `LiveWatch/build/outputs/LiveWatch.zip`

Copy that zip into `Aliucord/plugins/` on the phone and restart Aliucord.

## Notes
- Needs ~3–4 GB free RAM while the Discord APK is converted.
- Twitch Client ID + Secret are set later inside the plugin settings (not at build time).
