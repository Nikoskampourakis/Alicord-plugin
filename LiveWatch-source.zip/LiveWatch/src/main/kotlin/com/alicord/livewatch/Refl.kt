package com.alicord.livewatch

import android.content.res.Resources
import android.util.Log

internal fun dp(v: Float): Float = v * Resources.getSystem().displayMetrics.density
internal fun dp(v: Int): Int = (v * Resources.getSystem().displayMetrics.density).toInt()

internal fun logw(msg: String, t: Throwable? = null) {
    Log.w("LiveWatch", msg, t)
}

/** Reads a (possibly private) field by name. Discord's API models keep their field names even though methods are obfuscated. */
internal fun Any.fld(name: String): Any? {
    var c: Class<*>? = javaClass
    while (c != null) {
        try {
            val f = c.getDeclaredField(name)
            f.isAccessible = true
            return f.get(this)
        } catch (_: NoSuchFieldException) {
            c = c.superclass
        } catch (_: Throwable) {
            return null
        }
    }
    return null
}

internal fun Any.longFld(name: String): Long? = (fld(name) as? Number)?.toLong()
internal fun Any.strFld(name: String): String? = fld(name) as? String
