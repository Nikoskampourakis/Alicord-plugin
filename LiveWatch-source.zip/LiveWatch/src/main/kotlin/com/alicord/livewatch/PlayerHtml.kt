package com.alicord.livewatch

import org.json.JSONObject

/** Generated from player.html: the custom player page (hls.js + gestures, zoom, quality, speed, subtitles, transcript). */
object PlayerHtml {
    private const val TEMPLATE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
:root{--fg:#f2f3f5;--mut:#b5bac1;--acc:#5865f2;--pane:rgba(30,31,34,.94);--cue:16px}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
html,body{margin:0;height:100%;background:#000;overflow:hidden;font:13px/1.3 system-ui,-apple-system,Roboto,sans-serif;color:var(--fg)}
#stage{position:absolute;inset:0;overflow:hidden;touch-action:none}
#v{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;transform-origin:50% 50%;background:#000}
#v::cue{background:rgba(0,0,0,.72);color:#fff;font-size:var(--cue)}
.bar{position:absolute;left:0;right:0;display:flex;align-items:center;gap:6px;padding:8px 10px;transition:opacity .18s;z-index:3;background:rgba(0,0,0,.5)}
#top{top:0}
#bot{bottom:0;flex-direction:column;align-items:stretch}
.hide .bar,.hide #mid{opacity:0;pointer-events:none}
.btn{border:0;background:rgba(255,255,255,.12);color:var(--fg);border-radius:6px;padding:6px 9px;font:inherit;min-width:34px}
.btn.on{background:var(--acc)}
#title{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600}
#mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;transition:opacity .18s;z-index:2}
#pp{pointer-events:auto;width:56px;height:56px;border-radius:50%;border:0;background:rgba(0,0,0,.55);color:#fff;font-size:20px}
#seek{display:flex;align-items:center;gap:8px;padding:6px 0}
#sb{flex:1;height:22px;position:relative}
#sb:before{content:"";position:absolute;left:0;right:0;top:9px;height:4px;background:rgba(255,255,255,.25);border-radius:2px}
#sf{position:absolute;left:0;top:9px;height:4px;background:var(--acc);border-radius:2px;width:0}
#sk{position:absolute;top:11px;width:14px;height:14px;border-radius:50%;background:#fff;transform:translate(-50%,-50%);left:0}
#live{padding:3px 8px;border-radius:4px;font-weight:700;font-size:11px;background:#ed4245;border:0;color:#fff}
#live.behind{background:#4e5058}
#hint{position:absolute;top:18%;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.72);padding:6px 12px;border-radius:8px;opacity:0;transition:opacity .15s;z-index:5;pointer-events:none;white-space:nowrap}
#menu{position:absolute;right:8px;top:48px;max-height:70%;overflow:auto;min-width:170px;background:var(--pane);border-radius:8px;padding:4px;display:none;z-index:6}
#menu h4{margin:6px 8px;font-size:11px;color:var(--mut);text-transform:uppercase;letter-spacing:.04em}
#menu .it{padding:10px;border-radius:6px}
#menu .it.on{background:rgba(88,101,242,.35)}
#tr{position:absolute;right:0;top:0;bottom:0;width:min(78%,330px);background:var(--pane);display:none;flex-direction:column;z-index:7}
#trh{display:flex;gap:6px;align-items:center;padding:8px;border-bottom:1px solid rgba(255,255,255,.1)}
#trl{flex:1;overflow:auto;padding:6px 8px;-webkit-user-select:text;user-select:text}
#trl div{padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06)}
#trl b{color:var(--mut);margin-right:6px;font-weight:600}
#sub{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.72);z-index:8}
#sub .box{width:88%;background:var(--pane);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px}
#sub input,#sub textarea{width:100%;background:#1e1f22;border:1px solid #3f4147;color:#fff;border-radius:6px;padding:8px;font:inherit;-webkit-user-select:text;user-select:text}
#err{position:absolute;inset:0;display:none;align-items:center;justify-content:center;text-align:center;padding:24px;z-index:9;background:#000;color:var(--mut)}
</style></head><body>
<div id="stage">
 <video id="v" playsinline autoplay></video>
 <div id="mid"><button id="pp">&#9654;</button></div>
 <div id="top" class="bar"><div id="title"></div><button class="btn" id="bCC">CC</button><button class="btn" id="bQ">Auto</button><button class="btn" id="bS">1&times;</button><button class="btn" id="bT">&#8801;</button></div>
 <div id="bot" class="bar">
  <div id="seek"><span id="tc">0:00</span><div id="sb"><div id="sf"></div><div id="sk"></div></div><span id="td"></span></div>
  <div style="display:flex;gap:8px;align-items:center"><button id="live">LIVE</button><span style="flex:1"></span><button class="btn" id="bR">&#10227;</button><button class="btn" id="bF">&#9974;</button></div>
 </div>
 <div id="hint"></div>
 <div id="menu"></div>
 <div id="tr"><div id="trh"><b style="flex:1">Transcript</b><button class="btn" id="trCopy">Copy</button><button class="btn" id="trClose">&#10005;</button></div><div id="trl"></div></div>
 <div id="sub"><div class="box"><b>Load subtitles</b>
  <input id="subUrl" placeholder="URL to a .vtt / .srt file">
  <textarea id="subTxt" rows="5" placeholder="...or paste SRT / VTT text"></textarea>
  <div style="display:flex;gap:8px;justify-content:flex-end"><button class="btn" id="subCancel">Cancel</button><button class="btn on" id="subOk">Load</button></div></div></div>
</div>
<div id="err"></div>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js"></script>
<script>
window.ALC = __ALC_CONFIG__;
(function(){
var C = window.ALC || {};
var AB = window.AB || {lock:function(){},copy:function(){},fullscreen:function(){},failed:function(){}};
function g(id){return document.getElementById(id)}
var v=g('v'), stage=g('stage'), hls=null, ctrlTimer=null, retries=0;
var sc=1, tx=0, ty=0, bright=1, mode=null, start=null, pinch0=null, lastTap=0, tapTimer=null, seekTo=null;
var extra=[], tr=[], trSeen={}, rates=[0.5,0.75,1,1.25,1.5,2];
g('title').textContent = C.title || '';

function fmt(t){ if(!isFinite(t)||t<0)t=0; var h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=Math.floor(t%60); return (h?h+':'+(m<10?'0':'')+m:''+m)+':'+(s<10?'0':'')+s; }
function hint(s){var h=g('hint');h.textContent=s;h.style.opacity=1;clearTimeout(hint.t);hint.t=setTimeout(function(){h.style.opacity=0},900)}
function menuOpen(){return g('menu').style.display==='block'}
function showControls(){stage.classList.remove('hide');clearTimeout(ctrlTimer);if(!v.paused)ctrlTimer=setTimeout(function(){if(!menuOpen())stage.classList.add('hide')},3500)}
function fail(msg){g('err').style.display='flex';g('err').textContent=msg;try{AB.failed(msg)}catch(e){}}
function sr(){var s=v.seekable;if(s&&s.length)return{a:s.start(0),b:s.end(s.length-1)};return{a:0,b:isFinite(v.duration)?v.duration:0}}
function seekBy(d){var r=sr();v.currentTime=Math.max(r.a,Math.min(r.b-(C.live?1:0),v.currentTime+d))}
function goLive(){var r=sr();v.currentTime=(hls&&hls.liveSyncPosition)?hls.liveSyncPosition:Math.max(r.a,r.b-1.5)}

function ui(){
 var r=sr(),len=r.b-r.a,pos=len>0?(v.currentTime-r.a)/len:0;pos=Math.max(0,Math.min(1,pos));
 g('sf').style.width=(pos*100)+'%';g('sk').style.left=(pos*100)+'%';
 g('tc').textContent=C.live?'-'+fmt(Math.max(0,r.b-v.currentTime)):fmt(v.currentTime);
 g('td').textContent=C.live?'':fmt(v.duration);
 var behind=C.live&&(r.b-v.currentTime>8),lb=g('live');
 lb.style.display=C.live?'':'none';lb.className=behind?'behind':'';lb.textContent=behind?'GO LIVE':'\u25CF LIVE';
 g('pp').innerHTML=v.paused?'&#9654;':'&#10074;&#10074;';
}
setInterval(ui,500);v.addEventListener('play',showControls);v.addEventListener('pause',showControls);

/* ---------- playback ---------- */
function init(){
 if(hls){try{hls.destroy()}catch(e){}hls=null}
 g('err').style.display='none';
 if(window.Hls&&Hls.isSupported()){
  hls=new Hls({lowLatencyMode:true,enableWebVTT:true,enableCEA708Captions:true,backBufferLength:90});
  hls.on(Hls.Events.MANIFEST_PARSED,function(){g('bQ').textContent='Auto';v.play().catch(function(){})});
  hls.on(Hls.Events.LEVEL_SWITCHED,function(){if(hls.autoLevelEnabled&&hls.currentLevel>=0)g('bQ').textContent='Auto \u00B7 '+lvl(hls.levels[hls.currentLevel])});
  hls.on(Hls.Events.ERROR,function(e,d){
   if(!d.fatal)return;
   if(retries++>5)return fail('Playback error: '+d.details);
   if(d.type===Hls.ErrorTypes.NETWORK_ERROR)hls.startLoad();
   else if(d.type===Hls.ErrorTypes.MEDIA_ERROR)hls.recoverMediaError();
   else fail('Playback error: '+d.details);
  });
  hls.loadSource(C.src);hls.attachMedia(v);
 }else if(v.canPlayType('application/vnd.apple.mpegurl')){v.src=C.src}
 else fail(window.Hls?'This device cannot play HLS streams':'Could not load the player library (offline?)');
}

/* ---------- menus ---------- */
function menu(title,items){
 var m=g('menu');m.innerHTML='';var h=document.createElement('h4');h.textContent=title;m.appendChild(h);
 items.forEach(function(it){var d=document.createElement('div');d.className='it'+(it.on?' on':'');d.textContent=it.label;
  d.onclick=function(ev){ev.stopPropagation();m.style.display='none';if(it.fn)it.fn();showControls()};m.appendChild(d)});
 m.style.display='block';stage.classList.remove('hide');
}
function lvl(l){if(!l)return'?';if(l.name)return l.name;return l.height?l.height+'p':Math.round(l.bitrate/1000)+'k'}
function qualityMenu(){
 if(!hls||!hls.levels||!hls.levels.length)return hint('Quality unavailable');
 var cur=hls.currentLevel,auto=hls.autoLevelEnabled;
 var items=[{label:'Auto',on:auto,fn:function(){hls.currentLevel=-1;g('bQ').textContent='Auto'}}];
 for(var i=hls.levels.length-1;i>=0;i--){(function(i){items.push({label:lvl(hls.levels[i]),on:!auto&&cur===i,fn:function(){hls.currentLevel=i;g('bQ').textContent=lvl(hls.levels[i])}})})(i)}
 menu('Quality',items);
}
function speedMenu(){
 var note=C.live?'Speed (live: >1\u00D7 catches up)':'Speed';
 menu(note,rates.map(function(r){return{label:r+'\u00D7',on:v.playbackRate===r,fn:function(){v.playbackRate=r;g('bS').textContent=r+'\u00D7';hint('Speed '+r+'\u00D7')}}}));
}

/* ---------- subtitles + transcript ---------- */
function toVtt(t){t=t.replace(/\r/g,'');if(/^\s*WEBVTT/.test(t))return t;return 'WEBVTT\n\n'+t.replace(/(\d\d:\d\d:\d\d),(\d{3})/g,function(m,a,b){return a+'.'+b})}
function collect(t){
 if(t._w)return;t._w=1;
 function take(c){var k=c.startTime+'|'+c.text;if(!trSeen[k]){trSeen[k]=1;tr.push({t:c.startTime,x:c.text});if(g('tr').style.display==='flex')renderTr()}}
 t.addEventListener('cuechange',function(){var a=t.activeCues;if(a)for(var i=0;i<a.length;i++)take(a[i])});
 setTimeout(function(){if(t.cues)for(var j=0;j<t.cues.length;j++)take(t.cues[j])},400);
}
function selectTrack(t){
 for(var i=0;i<v.textTracks.length;i++){var x=v.textTracks[i];if(x.kind!=='metadata')x.mode='disabled'}
 if(hls)hls.subtitleDisplay=false;
 if(!t)return;
 t.mode='showing';tr=[];trSeen={};collect(t);
}
function addTrack(label,vtt){
 var el=document.createElement('track');el.kind='subtitles';el.label=label;
 el.src=URL.createObjectURL(new Blob([vtt],{type:'text/vtt'}));v.appendChild(el);
 selectTrack(el.track);hint('Subtitles: '+label);
}
function ccMenu(){
 var items=[{label:'Off',on:true,fn:function(){selectTrack(null)}}];
 if(hls&&hls.subtitleTracks)hls.subtitleTracks.forEach(function(t,i){items.push({label:t.name||t.lang||('Track '+(i+1)),fn:function(){selectTrack(null);hls.subtitleTrack=i;hls.subtitleDisplay=true;for(var k=0;k<v.textTracks.length;k++){if(v.textTracks[k].mode==='showing'){tr=[];trSeen={};collect(v.textTracks[k])}}}})});
 for(var i=0;i<v.textTracks.length;i++){(function(t){if(t.kind==='captions'||t.kind==='subtitles'){items.push({label:(t.label||t.language||'Captions'),on:t.mode==='showing',fn:function(){selectTrack(t)}})}})(v.textTracks[i])}
 (C.tracks||[]).forEach(function(t){items.push({label:t.label+' (YouTube)',fn:function(){
   fetch(t.url+'&fmt=vtt').then(function(r){return r.text()}).then(function(x){addTrack(t.label,toVtt(x))}).catch(function(){hint('Could not load captions')})}})});
 items.push({label:'Size: small',fn:function(){document.documentElement.style.setProperty('--cue','12px')}});
 items.push({label:'Size: medium',fn:function(){document.documentElement.style.setProperty('--cue','16px')}});
 items.push({label:'Size: large',fn:function(){document.documentElement.style.setProperty('--cue','22px')}});
 items.push({label:'Load file / URL\u2026',fn:function(){g('sub').style.display='flex'}});
 menu('Subtitles',items);
}
g('subCancel').onclick=function(){g('sub').style.display='none'};
g('subOk').onclick=function(){
 var u=g('subUrl').value.trim(),p=g('subTxt').value;g('sub').style.display='none';
 if(p.trim())addTrack('Custom '+(extra.length+1),toVtt(p));
 else if(u)fetch(u).then(function(r){return r.text()}).then(function(x){addTrack('Custom '+(extra.length+1),toVtt(x))}).catch(function(){hint('Could not load subtitles')});
 extra.push(1);
};
function renderTr(){
 var l=g('trl');l.innerHTML='';
 if(!tr.length){l.textContent='Pick a subtitle track first (CC). Lines appear here as they are shown.';return}
 var arr=C.live?tr:tr.slice().sort(function(a,b){return a.t-b.t});
 arr.forEach(function(c){var d=document.createElement('div');var b=document.createElement('b');b.textContent=fmt(c.t);d.appendChild(b);d.appendChild(document.createTextNode(c.x));
  d.onclick=function(){if(!C.live)v.currentTime=c.t};l.appendChild(d)});
 l.scrollTop=l.scrollHeight;
}
g('bT').onclick=function(e){e.stopPropagation();g('tr').style.display='flex';renderTr()};
g('trClose').onclick=function(){g('tr').style.display='none'};
g('trCopy').onclick=function(){AB.copy(tr.map(function(c){return '['+fmt(c.t)+'] '+c.x}).join('\n'));hint('Transcript copied')};

/* ---------- buttons ---------- */
g('bCC').onclick=function(e){e.stopPropagation();ccMenu()};
g('bQ').onclick=function(e){e.stopPropagation();qualityMenu()};
g('bS').onclick=function(e){e.stopPropagation();speedMenu()};
g('pp').onclick=function(e){e.stopPropagation();v.paused?v.play():v.pause()};
g('live').onclick=function(e){e.stopPropagation();goLive()};
g('bR').onclick=function(e){e.stopPropagation();retries=0;init();hint('Reloading stream')};
g('bF').onclick=function(e){e.stopPropagation();AB.fullscreen()};

/* ---------- seek bar ---------- */
var sb=g('sb');
function sbSeek(e){var t=e.touches[0],b=sb.getBoundingClientRect(),p=Math.max(0,Math.min(1,(t.clientX-b.left)/b.width)),r=sr();v.currentTime=r.a+p*(r.b-r.a);ui()}
sb.addEventListener('touchstart',function(e){e.stopPropagation();AB.lock(true);sbSeek(e)},{passive:true});
sb.addEventListener('touchmove',function(e){e.stopPropagation();sbSeek(e)},{passive:true});
sb.addEventListener('touchend',function(e){e.stopPropagation();AB.lock(false)},{passive:true});

/* ---------- gestures: tap, double-tap seek, swipe seek/volume/brightness, pinch zoom, pan ---------- */
function apply(){v.style.transform='translate('+tx+'px,'+ty+'px) scale('+sc+')'}
function clampPan(){var mx=(sc-1)*stage.clientWidth/2,my=(sc-1)*stage.clientHeight/2;tx=Math.max(-mx,Math.min(mx,tx));ty=Math.max(-my,Math.min(my,ty))}
function dist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY)}
function ignore(e){return !!(e.target.closest&&e.target.closest('.bar,#menu,#tr,#sub,#pp'))}
stage.addEventListener('touchstart',function(e){
 if(ignore(e))return;
 AB.lock(true);
 if(e.touches.length===2){mode='pinch';pinch0={d:dist(e.touches),sc:sc}}
 else if(e.touches.length===1){var t=e.touches[0];start={x:t.clientX,y:t.clientY,tx:tx,ty:ty,vol:v.volume,br:bright,pos:v.currentTime};mode='pending';seekTo=null}
},{passive:false});
stage.addEventListener('touchmove',function(e){
 if(ignore(e))return;e.preventDefault();
 if(mode==='pinch'&&e.touches.length===2){sc=Math.max(1,Math.min(5,pinch0.sc*dist(e.touches)/pinch0.d));clampPan();apply();hint(Math.round(sc*100)+'%');return}
 if(e.touches.length!==1||!start)return;
 var t=e.touches[0],dx=t.clientX-start.x,dy=t.clientY-start.y,W=stage.clientWidth,H=stage.clientHeight;
 if(mode==='pending'){if(Math.hypot(dx,dy)<10)return;if(sc>1)mode='pan';else mode=Math.abs(dx)>Math.abs(dy)?'seek':(start.x<W/2?'bright':'vol')}
 if(mode==='pan'){tx=start.tx+dx;ty=start.ty+dy;clampPan();apply()}
 else if(mode==='seek'){var r=sr(),span=C.live?120:Math.max(60,(r.b-r.a)/3);seekTo=Math.max(r.a,Math.min(r.b,start.pos+dx/W*span));hint((seekTo>=start.pos?'+':'-')+fmt(Math.abs(seekTo-start.pos)))}
 else if(mode==='vol'){v.volume=Math.max(0,Math.min(1,start.vol-dy/H*1.4));hint('Volume '+Math.round(v.volume*100)+'%')}
 else if(mode==='bright'){bright=Math.max(.3,Math.min(1.6,start.br-dy/H*1.4));v.style.filter='brightness('+bright+')';hint('Brightness '+Math.round(bright*100)+'%')}
},{passive:false});
stage.addEventListener('touchend',function(e){
 if(ignore(e))return;
 if(e.touches.length>0){mode='none';return}
 var wasTap=mode==='pending';
 if(mode==='seek'&&seekTo!==null)v.currentTime=seekTo;
 mode=null;AB.lock(false);
 if(wasTap&&start)tap(start.x);
},{passive:true});
function tap(x){
 var now=Date.now(),W=stage.clientWidth;
 if(now-lastTap<280){
  clearTimeout(tapTimer);lastTap=0;
  if(x<W/3){seekBy(-10);hint('\u2212 10 s')}
  else if(x>W*2/3){seekBy(10);hint('+ 10 s')}
  else if(sc>1){sc=1;tx=0;ty=0;apply();hint('Zoom reset')}
  else{v.paused?v.play():v.pause()}
 }else{
  lastTap=now;
  tapTimer=setTimeout(function(){if(stage.classList.contains('hide')||menuOpen()){g('menu').style.display='none';showControls()}else stage.classList.add('hide')},290);
 }
}

init();showControls();
})();
</script></body></html>
"""

    fun build(cfg: JSONObject): String = TEMPLATE.replace("__ALC_CONFIG__", cfg.toString().replace("</", "<\\/"))
}
