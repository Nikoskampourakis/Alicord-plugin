package com.alicord.livewatch

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.aliucord.Utils
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.api.CommandsAPI
import com.aliucord.entities.Plugin
import com.aliucord.patcher.Hook
import com.discord.api.commands.ApplicationCommandType
import com.discord.stores.StoreMessages
import com.discord.widgets.guilds.list.GuildListViewHolder
import com.discord.widgets.guilds.list.WidgetGuildListAdapter
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import kotlin.math.abs

object Notifier {
    @Volatile var openHub: (() -> Unit)? = null

    fun wentLive(list: List<LiveInfo>) {
        if (!Prefs.notifyLive) return
        if (list.size > 3) {
            Bridge.notify("${list.size} servers are live", list.take(3).joinToString { it.streamer } + "…") { openHub?.invoke() }
            return
        }
        list.forEach { i ->
            val server = Bridge.guild(i.guildId)?.name ?: ""
            Bridge.notify(
                "${i.streamer} is live on ${i.platform.label}",
                listOf(server, i.title).filter { it.isNotBlank() }.joinToString(" — "),
            ) { WatchRoom.open(RoomSpec.fromLive(i)) }
        }
    }
}

@AliucordPlugin
class LiveWatch : Plugin() {
    private var adapterRef: WeakReference<WidgetGuildListAdapter>? = null
    private val tapOwned = WeakHashMap<View, Boolean>()

    init {
        settingsTab = SettingsTab(HubPage::class.java, SettingsTab.Type.PAGE).withArgs(settings)
    }

    override fun start(context: Context) {
        Prefs.init(settings)
        Notifier.openHub = { Bridge.openPage(HubPage(settings)) }
        patchGuildList()
        patchMessages()
        registerCommands()
        LiveDetector.onChange = { refreshList() }
        LiveDetector.onWentLive = { Notifier.wentLive(it) }
        LiveDetector.restart()
    }

    override fun stop(context: Context) {
        LiveDetector.stop()
        LiveDetector.onChange = null
        LiveDetector.onWentLive = null
        patcher.unpatchAll()
        commands.unregisterAll()
        LiveRing.clearAll()
        refreshList()
    }

    private fun refreshList() = Bridge.ui { adapterRef?.get()?.notifyDataSetChanged() }

    // ---- server list: ring + tap -----------------------------------------------------------------------------

    private fun patchGuildList() {
        val m = WidgetGuildListAdapter::class.java.declaredMethods
            .firstOrNull { it.name == "onBindViewHolder" && !it.isBridge && !it.isSynthetic }
        if (m == null) {
            logger.error("WidgetGuildListAdapter.onBindViewHolder not found", null)
            return
        }
        patcher.patch(m, Hook { p ->
            try {
                val holder = p.args[0] as? RecyclerView.ViewHolder ?: return@Hook
                val adapter = p.thisObject as? WidgetGuildListAdapter ?: return@Hook
                decorate(holder, adapter, p.args[1] as Int)
            } catch (t: Throwable) {
                logger.error(t)
            }
        })
    }

    private fun decorate(holder: RecyclerView.ViewHolder, adapter: WidgetGuildListAdapter, position: Int) {
        if (holder !is GuildListViewHolder.GuildViewHolder) return
        adapterRef = WeakReference(adapter)
        val item: Any = adapter.getItem(position) ?: return
        val gid = item.fld("guild")?.longFld("id") ?: return

        val root = holder.itemView
        val wrap = root.findViewById<View>(Utils.getResId("guilds_item_avatar_wrap", "id")) ?: root
        val info = LiveDetector.live[gid]

        if (info == null || !Prefs.ring) {
            LiveRing.clear(wrap)
            if (tapOwned.remove(wrap) != null) wrap.setOnTouchListener(null)
            return
        }
        LiveRing.apply(wrap, info)

        if (Prefs.tapAction == "server") {
            if (tapOwned.remove(wrap) != null) wrap.setOnTouchListener(null)
            return
        }
        tapOwned[wrap] = true
        wrap.setOnTouchListener(TapInterceptor(root, onTap = { onLiveTap(gid) }))
    }

    private fun onLiveTap(guildId: Long) {
        val info = LiveDetector.live[guildId] ?: return
        when (Prefs.tapAction) {
            "ask" -> AlertDialog.Builder(Bridge.ctx())
                .setTitle("${info.streamer} is live")
                .setItems(arrayOf("Watch in Watch Room", "Open the server")) { _, which ->
                    if (which == 0) WatchRoom.open(RoomSpec.fromLive(info))
                    else Bridge.firstTextChannel(guildId)?.let { Bridge.openChannel(it) }
                }
                .show()
            else -> WatchRoom.open(RoomSpec.fromLive(info))
        }
    }

    /**
     * Swallows a short tap on a live server icon (so we can open the Watch Room instead of the server) while forwarding
     * long-presses and scrolls to Discord untouched.
     */
    private class TapInterceptor(private val row: View, private val onTap: () -> Unit) : View.OnTouchListener {
        private var x = 0f
        private var y = 0f
        private var moved = false
        private var longFired = false
        private val slop = ViewConfiguration.get(row.context).scaledTouchSlop
        private val longRun = Runnable {
            longFired = true
            row.performLongClick()
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x = e.x; y = e.y; moved = false; longFired = false
                    v.postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.x - x) > slop || abs(e.y - y) > slop) { moved = true; v.removeCallbacks(longRun) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(longRun)
                    if (!moved && !longFired) onTap()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longRun)
                    return true
                }
            }
            return false
        }
    }

    // ---- messages ----------------------------------------------------------------------------------------------

    private fun patchMessages() {
        val m = StoreMessages::class.java.declaredMethods.firstOrNull { it.name == "handleMessageCreate" }
        if (m == null) {
            logger.error("StoreMessages.handleMessageCreate not found", null)
            return
        }
        patcher.patch(m, Hook { p -> p.args.getOrNull(0)?.let { MessageSniffer.onMessage(it) } })
    }

    // ---- slash commands ------------------------------------------------------------------------------------------

    private fun registerCommands() {
        commands.registerCommand("livewatch", "Open the LiveWatch hub (who is live, join, settings)", emptyList()) {
            Notifier.openHub?.invoke()
            CommandsAPI.CommandResult("Opening LiveWatch…", null, false)
        }

        commands.registerCommand(
            "watchjoin", "Join a watch party with an invite code",
            listOf(Utils.createCommandOption(ApplicationCommandType.STRING, "code", "Invite code (alc1.…)", required = true)),
        ) { ctx ->
            val spec = RoomSpec.fromCode(ctx.getRequiredString("code"), ctx.channelId)
            if (spec == null) {
                CommandsAPI.CommandResult("That invite code isn't valid.", null, false)
            } else {
                WatchRoom.open(spec)
                CommandsAPI.CommandResult("Joining ${spec.streamer}…", null, false)
            }
        }

        commands.registerCommand("watchinvite", "Invite the people in this chat to the room you're watching", emptyList()) { ctx ->
            val room = WatchRoom.current
            if (room == null) {
                CommandsAPI.CommandResult("Open a Watch Room first (tap a live server icon), then run this again.", null, false)
            } else {
                WatchRoom.setParty(ctx.channelId)
                val code = room.toCode(ctx.channelId)
                CommandsAPI.CommandResult(
                    "🔴 Watch ${room.streamer} on ${room.platform.label} with me. Needs the Alicord LiveWatch plugin. Code: $code",
                    null, true,
                )
            }
        }
    }
}
