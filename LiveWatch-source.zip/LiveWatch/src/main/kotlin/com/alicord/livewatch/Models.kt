package com.alicord.livewatch

import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.Inflater

enum class Platform(val label: String, val color: Int, val tag: String) {
    TWITCH("Twitch", 0xFF9146FF.toInt(), "t"),
    YOUTUBE("YouTube", 0xFFFF0033.toInt(), "y");

    companion object {
        fun fromTag(t: String?) = values().firstOrNull { it.tag == t }
    }
}

/** One live stream attached to a guild. For Twitch `key` is the login; for YouTube it is the channel id (or video id for bot-detected lives). */
data class LiveInfo(
    val guildId: Long,
    val platform: Platform,
    val key: String,
    val streamer: String,
    val title: String,
    val videoId: String?,
    val viewers: Int?,
    val since: Long,
    val viaBot: Boolean,
) {
    val signature: String get() = "$guildId:${platform.tag}:${videoId ?: key}"

    val watchUrl: String
        get() = when (platform) {
            Platform.TWITCH -> "https://www.twitch.tv/$key"
            Platform.YOUTUBE ->
                if (videoId != null) "https://www.youtube.com/watch?v=$videoId"
                else "https://www.youtube.com/channel/$key/live"
        }
}

/** Everything needed to open a Watch Room. Also the payload of an invite code. */
data class RoomSpec(
    val platform: Platform,
    val key: String,
    val videoId: String?,
    val guildId: Long?,
    val partyChannelId: Long?,
    val streamer: String,
    val title: String?,
) {
    val watchUrl: String
        get() = when (platform) {
            Platform.TWITCH -> "https://www.twitch.tv/$key"
            Platform.YOUTUBE ->
                if (videoId != null) "https://www.youtube.com/watch?v=$videoId"
                else "https://www.youtube.com/channel/$key/live"
        }

    /** Self-contained invite code: no server involved, the whole room description is inside the code. */
    fun toCode(channelId: Long? = partyChannelId): String {
        val o = JSONObject().put("v", 1).put("p", platform.tag).put("k", key).put("n", streamer.take(40))
        videoId?.let { o.put("i", it) }
        guildId?.let { o.put("g", it) }
        channelId?.let { o.put("c", it) }
        title?.let { o.put("t", it.take(80)) }
        return CODE_PREFIX + pack(o.toString())
    }

    companion object {
        const val CODE_PREFIX = "alc1."
        val CODE_REGEX = Regex("alc1\\.[A-Za-z0-9_-]{8,1500}")
        private val TW = Regex("^[A-Za-z0-9_]{1,25}$")
        private val YT_ID = Regex("^[A-Za-z0-9_-]{11}$")
        private val YT_CH = Regex("^UC[A-Za-z0-9_-]{22}$")

        fun fromLive(i: LiveInfo, partyChannel: Long? = null) = RoomSpec(
            i.platform,
            i.key,
            i.videoId,
            i.guildId,
            partyChannel,
            i.streamer,
            i.title,
        )

        /** Codes come from other people, so everything is validated before it is ever put in a URL. */
        fun fromCode(text: String, fallbackChannel: Long? = null): RoomSpec? {
            val m = CODE_REGEX.find(text.trim()) ?: return null
            return try {
                val o = JSONObject(unpack(m.value.removePrefix(CODE_PREFIX)) ?: return null)
                val p = Platform.fromTag(o.optString("p")) ?: return null
                val k = o.optString("k")
                val vid = o.optString("i").takeIf { it.isNotEmpty() }
                val ok = when (p) {
                    Platform.TWITCH -> TW.matches(k)
                    Platform.YOUTUBE -> (vid != null && YT_ID.matches(vid)) || YT_CH.matches(k)
                }
                if (!ok) return null
                RoomSpec(
                    p, k, vid?.takeIf { YT_ID.matches(it) },
                    o.optLong("g", 0L).takeIf { it != 0L },
                    o.optLong("c", 0L).takeIf { it != 0L } ?: fallbackChannel,
                    o.optString("n").ifEmpty { k },
                    o.optString("t").takeIf { it.isNotEmpty() },
                )
            } catch (_: Throwable) {
                null
            }
        }

        private fun pack(s: String): String {
            val d = Deflater(9)
            d.setInput(s.toByteArray())
            d.finish()
            val out = ByteArrayOutputStream()
            val buf = ByteArray(256)
            while (!d.finished()) out.write(buf, 0, d.deflate(buf))
            d.end()
            return Base64.encodeToString(out.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        }

        private fun unpack(s: String): String? {
            val inf = Inflater()
            return try {
                inf.setInput(Base64.decode(s, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING))
                val out = ByteArrayOutputStream()
                val buf = ByteArray(256)
                var total = 0
                while (!inf.finished()) {
                    val n = inf.inflate(buf)
                    if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                    total += n
                    if (total > 8192) return null // zip-bomb guard
                    out.write(buf, 0, n)
                }
                out.toString("UTF-8")
            } catch (_: Throwable) {
                null
            } finally {
                inf.end()
            }
        }
    }
}
