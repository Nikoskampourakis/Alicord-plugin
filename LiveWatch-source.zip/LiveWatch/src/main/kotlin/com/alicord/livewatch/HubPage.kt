package com.alicord.livewatch

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.aliucord.Utils
import com.aliucord.api.SettingsAPI
import com.aliucord.fragments.SettingsPage
import com.aliucord.views.Button
import com.discord.views.CheckedSetting

/** Plugin settings page and the "Live now" hub: who is live, join-by-code, and all options. */
class HubPage(private val settingsApi: SettingsAPI) : SettingsPage() {
    override fun onViewBound(view: View) {
        super.onViewBound(view)
        Prefs.init(settingsApi)
        setActionBarTitle("LiveWatch")
        val ctx = view.context
        val col = linearLayout

        // ---- live now ----
        col.addView(heading(ctx, "Live now"))
        val live = LiveDetector.live.values.sortedBy { it.streamer.lowercase() }
        if (live.isEmpty()) col.addView(note(ctx, "Nobody you track is live right now."))
        live.forEach { i ->
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), dp(4), dp(16), dp(4)) }
            val server = Bridge.guild(i.guildId)?.name ?: "?"
            row.addView(TextView(ctx).apply {
                text = "● ${i.streamer} — $server\n${i.platform.label}" + (i.viewers?.let { " · $it watching" } ?: "") + (if (i.viaBot) " · via bot" else "")
                textSize = 14f
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(ctx).apply { text = "Watch"; setOnClickListener { WatchRoom.open(RoomSpec.fromLive(i)) } })
            col.addView(row)
        }
        col.addView(Button(ctx).apply { text = "Check now"; setOnClickListener { LiveDetector.refreshNow(); Utils.showToast("Checking…") } })

        // ---- join ----
        col.addView(heading(ctx, "Join a watch party"))
        val code = EditText(ctx).apply { hint = "Paste an alc1.… invite code"; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        col.addView(code)
        col.addView(Button(ctx).apply {
            text = "Join"
            setOnClickListener {
                val s = RoomSpec.fromCode(code.text.toString())
                if (s == null) Utils.showToast("That code isn't valid") else WatchRoom.open(s)
            }
        })

        // ---- behaviour ----
        col.addView(heading(ctx, "Behaviour"))
        switch(ctx, "Notify when someone goes live", "A notification you can tap to enter the Watch Room", Prefs::notifyLive)
        switch(ctx, "Live ring on server icons", "Coloured ring + LIVE pill (purple Twitch, red YouTube)", Prefs::ring) { LiveDetector.onChange?.invoke() }
        switch(ctx, "Pulse animation", null, Prefs::pulse)
        switch(ctx, "Rounded ring", "Use for rounded-square server icons", Prefs::roundedRing)
        switch(ctx, "Detect live-announcement bots", "Twitch/YouTube links posted by bots or webhooks", Prefs::botDetection)
        switch(ctx, "Detect watch-party invites in DMs", null, Prefs::inviteDetection)
        switch(ctx, "Start with the custom player", "Off = Twitch/YouTube's own embedded player", { Prefs.defaultPlayer == "custom" }) {
            Prefs.defaultPlayer = if (it) "custom" else "platform"
        }
        switch(ctx, "Tap on a live server opens the Watch Room", "Off = a normal tap opens the server (long-press is unchanged)", { Prefs.tapAction == "room" }) {
            Prefs.tapAction = if (it) "room" else "server"
        }

        // ---- tracking ----
        col.addView(heading(ctx, "Which servers"))
        switch(ctx, "Track every server I'm in", "Looks up each owner's public connections once every 12 h", Prefs::trackAll)
        col.addView(field(ctx, "Only these server IDs (when the switch is off)", Prefs.trackedIds) { Prefs.trackedIds = it })
        col.addView(field(ctx, "Check interval in seconds (60–900)", Prefs.pollSecondsRaw) {
            Prefs.pollSecondsRaw = it
            LiveDetector.restart()
        })

        // ---- twitch ----
        col.addView(heading(ctx, "Twitch (free, needed to detect Twitch lives)"))
        col.addView(note(ctx, "Create an app at dev.twitch.tv/console, then paste its Client ID and a Client Secret. They stay on this device."))
        col.addView(field(ctx, "Client ID", Prefs.twitchClientId) { Prefs.twitchClientId = it })
        col.addView(field(ctx, "Client Secret", Prefs.twitchClientSecret) { Prefs.twitchClientSecret = it })
        col.addView(note(ctx, "YouTube needs no key."))
    }

    private fun heading(ctx: Context, t: String) = TextView(ctx).apply {
        text = t
        textSize = 16f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(16), dp(20), dp(16), dp(6))
    }

    private fun note(ctx: Context, t: String) = TextView(ctx).apply {
        text = t
        textSize = 13f
        alpha = 0.7f
        setPadding(dp(16), dp(2), dp(16), dp(6))
    }

    private fun field(ctx: Context, hint: String, value: String, onChange: (String) -> Unit) = EditText(ctx).apply {
        this.hint = hint
        setText(value)
        textSize = 14f
        setPadding(dp(16), dp(10), dp(16), dp(10))
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange(s?.toString()?.trim() ?: "")
        })
    }

    private fun switch(ctx: Context, title: String, sub: String?, prop: kotlin.reflect.KMutableProperty0<Boolean>, after: (() -> Unit)? = null) =
        switch(ctx, title, sub, { prop.get() }) { prop.set(it); after?.invoke() }

    private fun switch(ctx: Context, title: String, sub: String?, get: () -> Boolean, set: (Boolean) -> Unit) {
        val s = Utils.createCheckedSetting(ctx, CheckedSetting.ViewType.SWITCH, title, sub)
        s.isChecked = get()
        s.setOnCheckedListener { v -> set(v) }
        linearLayout.addView(s)
    }
}
