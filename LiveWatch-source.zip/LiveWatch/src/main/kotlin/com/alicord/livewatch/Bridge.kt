package com.alicord.livewatch

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.aliucord.Http
import com.aliucord.Utils
import com.aliucord.api.NotificationsAPI
import com.aliucord.entities.NotificationData
import com.discord.stores.StoreStream
import com.discord.utilities.channel.ChannelSelector
import org.json.JSONArray
import org.json.JSONObject

/**
 * Every call into Discord/Aliucord internals lives in this one file.
 * If a Discord update renames something, this is the only place that needs touching.
 */
object Bridge {
    data class GuildLite(val id: Long, val name: String, val ownerId: Long, val icon: String?)
    data class ChatMsg(val id: String, val author: String, val content: String)

    val main = Handler(Looper.getMainLooper())

    fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    fun ctx(): Context = Utils.appActivity ?: Utils.appContext

    fun toast(msg: String) = ui { Utils.showToast(msg) }

    // ---- stores -----------------------------------------------------------------------------------------------

    fun guilds(): List<GuildLite> = try {
        StoreStream.getGuilds().guilds.values.map { GuildLite(it.id, it.name ?: "", it.ownerId, it.icon) }
    } catch (t: Throwable) {
        logw("guilds()", t)
        emptyList()
    }

    fun guild(id: Long): GuildLite? = guilds().firstOrNull { it.id == id }

    fun meId(): Long = try {
        StoreStream.getUsers().me.id
    } catch (_: Throwable) {
        0L
    }

    private fun channelsOf(guildId: Long): List<Any> = try {
        StoreStream.getChannels().getChannelsForGuild(guildId).values.toList()
    } catch (t: Throwable) {
        logw("channelsOf", t)
        emptyList()
    }

    private fun firstChannel(guildId: Long, type: Int): Long? = channelsOf(guildId)
        .filter { (it.fld("type") as? Number)?.toInt() == type }
        .minByOrNull { (it.fld("position") as? Number)?.toInt() ?: Int.MAX_VALUE }
        ?.longFld("id")

    fun firstTextChannel(guildId: Long) = firstChannel(guildId, 0)
    fun firstVoiceChannel(guildId: Long) = firstChannel(guildId, 2)

    // ---- navigation -------------------------------------------------------------------------------------------

    fun openChannel(channelId: Long) = ui {
        try {
            ChannelSelector.getInstance().findAndSet(ctx(), channelId)
        } catch (t: Throwable) {
            logw("openChannel", t)
            toast("Couldn't open that channel")
        }
    }

    /** Joins a guild voice channel. For DMs we open the chat so you can use Discord's own call button. */
    fun joinVoice(channelId: Long, isGuildChannel: Boolean) = ui {
        try {
            if (!isGuildChannel) return@ui openChannel(channelId)
            val store = StoreStream.getVoiceChannelSelected()
            store.javaClass.getMethod("selectVoiceChannel", Long::class.javaPrimitiveType).invoke(store, channelId)
            toast("Joining voice…")
        } catch (t: Throwable) {
            logw("joinVoice", t)
            openChannel(channelId)
        }
    }

    fun openPage(page: androidx.fragment.app.Fragment) = ui { Utils.openPageWithProxy(ctx(), page) }

    // ---- notifications ----------------------------------------------------------------------------------------

    fun notify(title: String, body: String, onClick: () -> Unit) = ui {
        try {
            val d = NotificationData().setTitle(title).setBody(body).setAutoDismissPeriodSecs(12)
            d.setOnClick { onClick() }
            NotificationsAPI.display(d)
        } catch (t: Throwable) {
            logw("notify", t)
            Utils.showToast("$title — $body")
        }
    }

    // ---- Discord REST -----------------------------------------------------------------------------------------

    fun restGet(route: String): String? = try {
        val r = Http.Request.newDiscordRNRequest(route, "GET").execute()
        if (r.ok()) r.text() else null
    } catch (t: Throwable) {
        logw("GET $route", t)
        null
    }

    fun restPost(route: String, body: Map<String, Any?>): String? = try {
        val r = Http.Request.newDiscordRNRequest(route, "POST").executeWithJson(body)
        if (r.ok()) r.text() else null
    } catch (t: Throwable) {
        logw("POST $route", t)
        null
    }

    /** Public profile; `connected_accounts` only lists connections the owner made visible. */
    fun profileConnections(userId: Long): JSONArray? =
        restGet("/users/$userId/profile?with_mutual_guilds=false&with_mutual_friends=false")
            ?.let { runCatching { JSONObject(it).optJSONArray("connected_accounts") }.getOrNull() }

    fun sendMessage(channelId: Long, text: String): Boolean =
        restPost("/channels/$channelId/messages", mapOf("content" to text, "tts" to false)) != null

    fun messages(channelId: Long, limit: Int = 40): List<ChatMsg> {
        val txt = restGet("/channels/$channelId/messages?limit=$limit") ?: return emptyList()
        return try {
            val arr = JSONArray(txt)
            (arr.length() - 1 downTo 0).map { i ->
                val o = arr.getJSONObject(i)
                val a = o.optJSONObject("author")
                val name = a?.optString("global_name").takeUnless { it.isNullOrEmpty() || it == "null" }
                    ?: a?.optString("username") ?: "?"
                var content = o.optString("content")
                if (content.isEmpty() && o.optJSONArray("attachments")?.length() ?: 0 > 0) content = "[attachment]"
                ChatMsg(o.optString("id"), name, content)
            }
        } catch (t: Throwable) {
            logw("messages", t)
            emptyList()
        }
    }
}
