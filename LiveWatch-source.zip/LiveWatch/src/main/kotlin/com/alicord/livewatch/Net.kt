package com.alicord.livewatch

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Plain HttpURLConnection helpers. The plugin only talks to Discord, Twitch and YouTube; there is no other server. */
object Net {
    const val UA_DESKTOP =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    const val UA_MOBILE =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    /** YouTube serves an EU consent wall unless this cookie is present. */
    val YT_HEADERS = mapOf("Cookie" to "SOCS=CAI; CONSENT=YES+1", "Accept-Language" to "en-US,en;q=0.9")

    val io: ExecutorService = Executors.newCachedThreadPool { r -> Thread(r, "LiveWatch-io").apply { isDaemon = true } }

    class Resp(val code: Int, val body: String) {
        val ok get() = code in 200..299
    }

    fun fetch(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        maxBytes: Int = 1_500_000,
    ): Resp? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", headers["User-Agent"] ?: UA_DESKTOP)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            Resp(code, stream?.use { readCapped(it, maxBytes) } ?: "")
        } catch (t: Throwable) {
            logw("fetch failed: $url", t)
            null
        } finally {
            c?.disconnect()
        }
    }

    fun getText(url: String, headers: Map<String, String> = emptyMap(), maxBytes: Int = 1_500_000): String? =
        fetch("GET", url, headers, null, maxBytes)?.takeIf { it.ok }?.body

    private fun readCapped(s: InputStream, max: Int): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        while (out.size() < max) {
            val n = s.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }
}
