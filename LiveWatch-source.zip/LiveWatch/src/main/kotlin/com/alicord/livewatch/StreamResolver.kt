package com.alicord.livewatch

import org.json.JSONObject
import java.net.URLEncoder

/**
 * Finds a raw HLS URL for the custom player.
 *
 *  - YouTube: the live watch page exposes `hlsManifestUrl`.
 *  - Twitch: same unofficial playback-token flow that Streamlink and yt-dlp use. It is not a supported public API,
 *    so it can break; the Watch Room falls back to Twitch's own embedded player when it does.
 */
object StreamResolver {
    class Track(val label: String, val url: String)
    class Resolved(val src: String, val live: Boolean, val tracks: List<Track>)

    private const val TWITCH_WEB_CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"
    private const val TWITCH_TOKEN_HASH = "0828119ded1c13477966434e15800ff57ddacf13ba1911c129dc2200705b0712"

    fun resolve(spec: RoomSpec): Resolved = when (spec.platform) {
        Platform.TWITCH -> twitch(spec.key)
        Platform.YOUTUBE -> youtube(spec)
    }

    private fun twitch(login: String): Resolved {
        val q = JSONObject()
            .put("operationName", "PlaybackAccessToken")
            .put(
                "variables",
                JSONObject().put("isLive", true).put("login", login).put("isVod", false).put("vodID", "").put("playerType", "site"),
            )
            .put(
                "extensions",
                JSONObject().put("persistedQuery", JSONObject().put("version", 1).put("sha256Hash", TWITCH_TOKEN_HASH)),
            )
        val r = Net.fetch(
            "POST", "https://gql.twitch.tv/gql",
            mapOf("Client-ID" to TWITCH_WEB_CLIENT_ID, "Content-Type" to "application/json"),
            q.toString(),
        ) ?: throw IllegalStateException("Twitch unreachable")
        if (!r.ok) throw IllegalStateException("Twitch refused the playback token (${r.code})")
        val t = JSONObject(r.body).optJSONObject("data")?.optJSONObject("streamPlaybackAccessToken")
            ?: throw IllegalStateException("$login is not live")
        val token = t.getString("value")
        val sig = t.getString("signature")
        val url = "https://usher.ttvnw.net/api/channel/hls/" + login.lowercase() + ".m3u8" +
            "?allow_source=true&allow_audio_only=true&fast_bread=true&player_backend=mediaplayer" +
            "&playlist_include_framerate=true&reassignments_supported=true&supported_codecs=avc1" +
            "&p=" + (Math.random() * 999999).toInt() +
            "&sig=" + sig + "&token=" + URLEncoder.encode(token, "UTF-8")
        return Resolved(url, true, emptyList())
    }

    private fun youtube(spec: RoomSpec): Resolved {
        var id = spec.videoId
        if (id == null) {
            val html = Net.getText("https://www.youtube.com/channel/${spec.key}/live", Net.YT_HEADERS)
                ?: throw IllegalStateException("YouTube unreachable")
            id = LiveDetector.parseYtLive(html, 0L)?.videoId ?: throw IllegalStateException("Channel is not live")
        }
        val html = Net.getText("https://www.youtube.com/watch?v=$id", Net.YT_HEADERS, 3_000_000)
            ?: throw IllegalStateException("YouTube unreachable")
        val m = Regex("\"hlsManifestUrl\":\"([^\"]+)\"").find(html)
            ?: throw IllegalStateException("YouTube did not expose a stream manifest")
        val src = JSONObject("{\"u\":\"" + m.groupValues[1] + "\"}").getString("u")
        return Resolved(src, html.contains("\"isLive\":true"), captionTracks(html))
    }

    /** Caption tracks (usually only present on VODs / finished streams). Fetched later as WebVTT. */
    private fun captionTracks(html: String): List<Track> {
        val start = html.indexOf("\"captionTracks\":[")
        if (start < 0) return emptyList()
        val seg = html.substring(start, minOf(html.length, start + 8000)).substringBefore("\"audioTracks\"")
        val urls = Regex("\"baseUrl\":\"([^\"]+)\"").findAll(seg).map { it.groupValues[1] }.toList()
        val names = Regex("\"languageCode\":\"([^\"]+)\"").findAll(seg).map { it.groupValues[1] }.toList()
        return urls.mapIndexedNotNull { i, u ->
            runCatching {
                val clean = JSONObject("{\"u\":\"$u\"}").getString("u")
                Track(names.getOrNull(i) ?: "Track ${i + 1}", clean)
            }.getOrNull()
        }.take(12)
    }
}
