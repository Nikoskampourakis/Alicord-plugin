package com.alicord.livewatch

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.NestedScrollView
import com.aliucord.Utils
import com.aliucord.fragments.SettingsPage
import com.aliucord.views.Button

object WatchRoom {
    @Volatile var current: RoomSpec? = null

    /** Set by /watchinvite: the channel (usually a DM) that becomes this room's party chat and call. */
    @Volatile var partyChannel: Long? = null
    @Volatile var onPartyChanged: (() -> Unit)? = null

    fun setParty(channelId: Long) {
        partyChannel = channelId
        onPartyChanged?.invoke()
    }

    fun open(spec: RoomSpec) {
        current = spec
        partyChannel = spec.partyChannelId
        Bridge.openPage(WatchRoomPage(spec))
    }
}

/**
 * The "virtual server": a full page that looks like a small server of its own – header with the real server's name,
 * the stream on top, and Chat / Voice / Info tabs underneath. Nothing is created on Discord's side.
 */
class WatchRoomPage @JvmOverloads constructor(private val spec: RoomSpec? = null) : SettingsPage(), PlayerView.Callbacks {
    private companion object {
        const val BG = 0xFF1E1F22.toInt()
        const val PANEL = 0xFF2B2D31.toInt()
        const val TEXT = 0xFFF2F3F5.toInt()
        const val MUTED = 0xFFB5BAC1.toInt()
        const val BRAND = 0xFF5865F2.toInt()
    }

    private var player: PlayerView? = null
    private lateinit var playerBox: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var togglePlayer: Button
    private val hideInFullscreen = ArrayList<View>()
    private var fullscreen = false
    private var custom = Prefs.defaultPlayer == "custom"
    private var tab = 0
    private val tabViews = arrayOfNulls<View>(3)
    private val tabLabels = ArrayList<TextView>()

    private var chatTarget = 0 // 0 = party channel, 1 = server channel
    private var chatList: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var lastSig = ""
    private var polling = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!polling) return
            if (tab == 0) fetchChat()
            Bridge.main.postDelayed(this, 5000)
        }
    }

    private fun partyChannel() = WatchRoom.partyChannel ?: spec?.partyChannelId
    private fun serverChannel() = spec?.guildId?.let { Bridge.firstTextChannel(it) }
    private fun chatChannel() = if (chatTarget == 0) partyChannel() ?: serverChannel() else serverChannel()

    override fun onViewBound(view: View) {
        super.onViewBound(view)
        val s = spec ?: run {
            Utils.showToast("That room was closed")
            activity?.finish()
            return
        }
        val ctx = view.context
        if (partyChannel() == null) chatTarget = 1

        val guildName = s.guildId?.let { Bridge.guild(it)?.name }
        setActionBarTitle(s.streamer)
        setActionBarSubtitle("● LIVE on ${s.platform.label}" + (guildName?.let { " · $it" } ?: ""))

        (linearLayout.parent as? NestedScrollView)?.isFillViewport = true
        linearLayout.apply {
            setPadding(0, 0, 0, 0)
            setBackgroundColor(BG)
            layoutParams = layoutParams?.apply { height = ViewGroup.LayoutParams.MATCH_PARENT }
        }

        // player (16:9)
        playerBox = FrameLayout(ctx).apply { setBackgroundColor(Color.BLACK) }
        linearLayout.addView(playerBox, LinearLayout.LayoutParams(-1, dp(210)))
        playerBox.post { if (!fullscreen) playerBox.layoutParams = LinearLayout.LayoutParams(-1, playerBox.width * 9 / 16) }
        player = PlayerView(ctx, this).also { playerBox.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        loadPlayer()

        // action row
        val actions = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(PANEL)
        }
        togglePlayer = Button(ctx).apply { setOnClickListener { custom = !custom; loadPlayer() } }
        actions.addView(togglePlayer, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(ctx).apply { text = "Fullscreen"; setOnClickListener { setFullscreen(!fullscreen) } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(ctx).apply { text = "Invite"; setOnClickListener { showInvite(ctx) } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(ctx).apply {
            text = "Server"
            setOnClickListener { serverChannel()?.let { Bridge.openChannel(it) } ?: Utils.showToast("No server channel available") }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        linearLayout.addView(actions)
        hideInFullscreen.add(actions)

        // tabs
        val tabs = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(PANEL) }
        listOf("Chat", "Voice", "Info").forEachIndexed { i, name ->
            val t = TextView(ctx).apply {
                text = name
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { selectTab(i) }
            }
            tabLabels.add(t)
            tabs.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        linearLayout.addView(tabs)
        hideInFullscreen.add(tabs)

        content = FrameLayout(ctx).apply { minimumHeight = dp(240) }
        linearLayout.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        hideInFullscreen.add(content)

        selectTab(if (chatChannel() != null) 0 else 2)
        WatchRoom.onPartyChanged = {
            Bridge.ui {
                tabViews[0] = null
                tabViews[1] = null
                chatTarget = 0
                lastSig = ""
                if (isAdded) selectTab(0)
            }
        }
        polling = true
        Bridge.main.post(pollRunnable)
    }

    override fun onDestroyView() {
        polling = false
        Bridge.main.removeCallbacks(pollRunnable)
        player?.release()
        player = null
        if (fullscreen) setFullscreen(false)
        WatchRoom.onPartyChanged = null
        if (WatchRoom.current === spec) {
            WatchRoom.current = null
            WatchRoom.partyChannel = null
        }
        super.onDestroyView()
    }

    // ---- player -----------------------------------------------------------------------------------------------

    private fun loadPlayer() {
        val s = spec ?: return
        togglePlayer.text = if (custom) "Player: Custom" else "Player: Platform"
        if (custom) player?.loadCustom(s) else player?.loadPlatform(s)
    }

    override fun onFullscreenToggle() = setFullscreen(!fullscreen)

    override fun onCustomFailed(msg: String) {
        Bridge.toast("Custom player failed: $msg — using the platform player")
        custom = false
        loadPlayer()
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        hideInFullscreen.forEach { it.visibility = if (on) View.GONE else View.VISIBLE }
        playerBox.layoutParams = if (on) LinearLayout.LayoutParams(-1, -1)
        else LinearLayout.LayoutParams(-1, maxOf(playerBox.width, 1) * 9 / 16)
        val a = activity ?: return
        a.requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        a.window.decorView.systemUiVisibility = if (on) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        } else View.SYSTEM_UI_FLAG_VISIBLE
        try {
            a.findViewById<View>(Utils.getResId("action_bar_toolbar", "id"))?.visibility = if (on) View.GONE else View.VISIBLE
        } catch (_: Throwable) {
        }
    }

    // ---- tabs -------------------------------------------------------------------------------------------------

    private fun selectTab(i: Int) {
        tab = i
        tabLabels.forEachIndexed { n, t ->
            t.setTextColor(if (n == i) TEXT else MUTED)
            t.setTypeface(null, if (n == i) Typeface.BOLD else Typeface.NORMAL)
        }
        val ctx = content.context
        val v = tabViews[i] ?: when (i) {
            0 -> buildChat(ctx)
            1 -> buildVoice(ctx)
            else -> buildInfo(ctx)
        }.also { tabViews[i] = it }
        content.removeAllViews()
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
        if (i == 0) fetchChat()
    }

    private fun label(ctx: Context, text: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    // ---- chat -------------------------------------------------------------------------------------------------

    private fun buildChat(ctx: Context): View {
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(6), dp(10), dp(6)) }

        val chips = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(text: String, target: Int) = TextView(ctx).apply {
            this.text = text
            textSize = 12f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { chatTarget = target; lastSig = ""; refreshChips(chips); fetchChat() }
        }
        if (partyChannel() != null) chips.addView(chip("Party chat", 0))
        if (serverChannel() != null) chips.addView(chip("Server chat", 1))
        refreshChips(chips)
        root.addView(chips)

        if (chatChannel() == null) {
            root.addView(
                label(ctx, "No chat channel yet.\n\nTo talk with a friend: open any DM with them and send /watchinvite. " +
                    "That DM becomes this room's chat, and you can call from it with Discord's normal voice controls.", 13f, MUTED),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) },
            )
            return root
        }

        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ctx).apply { addView(list) }
        chatList = list
        chatScroll = scroll
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(ctx).apply {
            hint = "Message"
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            textSize = 14f
            maxLines = 3
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(ctx).apply {
            text = "Send"
            setOnClickListener {
                val t = input.text.toString().trim()
                val ch = chatChannel()
                if (t.isEmpty() || ch == null) return@setOnClickListener
                input.setText("")
                Net.io.execute {
                    val ok = Bridge.sendMessage(ch, t)
                    if (!ok) Bridge.toast("Couldn't send that message") else fetchChat()
                }
            }
        })
        root.addView(row)
        return root
    }

    private fun refreshChips(chips: LinearLayout) {
        for (i in 0 until chips.childCount) {
            val c = chips.getChildAt(i) as TextView
            val target = if (c.text == "Party chat") 0 else 1
            c.setTextColor(if (target == chatTarget) TEXT else MUTED)
            c.setBackgroundColor(if (target == chatTarget) BRAND else Color.TRANSPARENT)
        }
    }

    private fun fetchChat() {
        val ch = chatChannel() ?: return
        Net.io.execute {
            val msgs = Bridge.messages(ch)
            val sig = ch.toString() + ":" + msgs.lastOrNull()?.id + ":" + msgs.size
            Bridge.ui {
                val list = chatList ?: return@ui
                if (sig == lastSig) return@ui
                lastSig = sig
                list.removeAllViews()
                msgs.forEach { m ->
                    val sb = SpannableStringBuilder(m.author)
                    sb.setSpan(StyleSpan(Typeface.BOLD), 0, m.author.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(0xFFA5B4FC.toInt()), 0, m.author.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.append("  ").append(m.content)
                    list.addView(TextView(list.context).apply {
                        text = sb
                        textSize = 14f
                        setTextColor(TEXT)
                        setPadding(0, dp(3), 0, dp(3))
                        setTextIsSelectable(true)
                    })
                }
                chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    // ---- voice ------------------------------------------------------------------------------------------------

    private fun buildVoice(ctx: Context): View {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        col.addView(label(ctx, "Talk while you watch", 16f, TEXT, true))
        col.addView(
            label(ctx, "Voice runs through Discord itself, so you keep every normal control (mute, deafen, volume, PTT). " +
                "Join a call and come back to this room; the stream keeps playing.", 13f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(12) },
        )
        val s = spec
        val vc = s?.guildId?.let { Bridge.firstVoiceChannel(it) }
        val party = partyChannel()
        if (party != null) col.addView(Button(ctx).apply { text = "Open party chat / call"; setOnClickListener { Bridge.openChannel(party) } })
        if (vc != null) col.addView(Button(ctx).apply { text = "Join server voice channel"; setOnClickListener { Bridge.joinVoice(vc, true) } })
        val serverText = s?.guildId?.let { Bridge.firstTextChannel(it) }
        if (serverText != null) col.addView(Button(ctx).apply { text = "Open the real server"; setOnClickListener { Bridge.openChannel(serverText) } })
        if (party == null && vc == null) {
            col.addView(label(ctx, "No voice target yet. Send /watchinvite in a DM with a friend to make that DM this room's party call.", 13f, MUTED))
        }
        return col
    }

    // ---- info / invite ----------------------------------------------------------------------------------------

    private fun buildInfo(ctx: Context): View {
        val s = spec!!
        val live = s.guildId?.let { LiveDetector.live[it] }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        col.addView(label(ctx, s.title ?: s.streamer, 16f, TEXT, true))
        col.addView(label(ctx, "${s.streamer} · ${s.platform.label}" + (live?.viewers?.let { " · $it watching" } ?: ""), 13f, MUTED))
        col.addView(label(ctx, if (live?.viaBot == true) "Detected from a live announcement in the server" else "Detected from the server owner's connected account", 12f, MUTED))

        col.addView(Button(ctx).apply { text = "Open on ${s.platform.label}"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.watchUrl))) } })
        col.addView(Button(ctx).apply { text = "Copy invite code"; setOnClickListener { copy(ctx, s.toCode(chatChannel())) } })

        col.addView(label(ctx, "Join a friend's room", 14f, TEXT, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val code = EditText(ctx).apply { hint = "alc1.…"; setTextColor(TEXT); setHintTextColor(MUTED); textSize = 13f; maxLines = 2 }
        col.addView(code)
        col.addView(Button(ctx).apply {
            text = "Join with code"
            setOnClickListener {
                val sp = RoomSpec.fromCode(code.text.toString())
                if (sp == null) Utils.showToast("That code isn't valid") else WatchRoom.open(sp)
            }
        })
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun showInvite(ctx: Context) {
        val s = spec ?: return
        val code = s.toCode(chatChannel())
        AlertDialog.Builder(ctx)
            .setTitle("Invite a friend")
            .setMessage("Friends with this plugin can paste the code in Info → Join, or use /watchjoin.\n\nTip: /watchinvite in any DM sends it for you and makes that DM your party chat.\n\n$code")
            .setPositiveButton("Copy") { _, _ -> copy(ctx, code) }
            .setNeutralButton("Share") { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Watch ${s.streamer} with me (Alicord LiveWatch): $code"), "Share invite"))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("invite", text))
        Utils.showToast("Copied")
    }
}
