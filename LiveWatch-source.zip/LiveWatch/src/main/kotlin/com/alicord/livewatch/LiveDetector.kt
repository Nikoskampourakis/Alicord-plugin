package com.alicord.livewatch

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Two sources of "this server is live":
 *  1. OWNER  – the guild owner's visible Twitch/YouTube connections, polled (Twitch Helix, YouTube live page).
 *  2. BOT    – live-announcement bots/webhooks posting in the guild (see MessageSniffer), verified when possible.
 * Owner detection wins when both exist.
 */
object LiveDetector {
    private const val H = 3_600_000L

    private class Links(val twitchId: String?, val ytChannel: String?, val ytName: String?, val at: Long)

    private val exec = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "LiveWatch-poll").apply { isDaemon = true } }
    private var task: ScheduledFuture<*>? = null

    private val links = ConcurrentHashMap<Long, Links>()
    private val ownerTwitch = ConcurrentHashMap<Long, LiveInfo>()
    private val ownerYt = ConcurrentHashMap<Long, LiveInfo>()
    private val bots = ConcurrentHashMap<Long, LiveInfo>()
    private val announced = HashSet<String>()

    @Volatile var live: Map<Long, LiveInfo> = emptyMap()
        private set
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var onWentLive: ((List<LiveInfo>) -> Unit)? = null

    private var token: String? = null
    private var tokenExp = 0L
    private var lastYt = 0L
    private var firstScanDone = false

    fun restart() {
        stop()
        task = exec.scheduleWithFixedDelay(
            { guard { tick(false) } }, 2, Prefs.pollSeconds.toLong(), TimeUnit.SECONDS,
        )
    }

    fun stop() {
        task?.cancel(false)
        task = null
    }

    fun refreshNow() {
        exec.execute { guard { tick(true) } }
    }

    private inline fun guard(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            logw("detector", t)
        }
    }

    // ---- polling ----------------------------------------------------------------------------------------------

    private fun tick(force: Boolean) {
        val now = System.currentTimeMillis()
        val guilds = Bridge.guilds().filter { Prefs.tracks(it.id) }
        val ids = guilds.map { it.id }.toSet()

        // 1. owner connections (cached 12h, max 6 lookups per tick so we never burst Discord's API)
        var budget = 6
        for (g in guilds) {
            val l = links[g.ownerId]
            if (l == null || now - l.at > 12 * H) {
                if (budget-- <= 0) break
                links[g.ownerId] = fetchLinks(g.ownerId)
                Thread.sleep(1200)
            }
        }

        // 2. Twitch: one batched Helix call
        val tw = guilds.mapNotNull { g -> links[g.ownerId]?.twitchId?.let { it to g } }
        if (tw.isNotEmpty() && Prefs.twitchReady()) {
            val streams = helixStreams("user_id", tw.map { it.first }.distinct())
            if (streams != null) {
                ownerTwitch.clear()
                for ((uid, g) in tw) streams[uid]?.let { ownerTwitch[g.id] = twitchInfo(g.id, it, false) }
            }
        }

        // 3. YouTube: slower cadence because each check downloads a page
        if (force || now - lastYt >= maxOf(Prefs.pollSeconds * 2L, 180L) * 1000) {
            lastYt = now
            val next = HashMap<Long, LiveInfo>()
            for (g in guilds) {
                val ch = links[g.ownerId]?.ytChannel ?: continue
                val html = Net.getText("https://www.youtube.com/channel/$ch/live", Net.YT_HEADERS, 800_000)
                parseYtLive(html ?: "", g.id)?.let { next[g.id] = it.copy(key = ch, streamer = it.streamer.ifEmpty { links[g.ownerId]?.ytName ?: ch }) }
                Thread.sleep(700)
            }
            ownerYt.clear()
            ownerYt.putAll(next)
        }

        // 4. bot-announced lives: re-verify the old ones, drop what ended
        for ((gid, info) in bots.entries.toList()) {
            if (now - info.since > 20 * 60_000L) {
                when (verify(info)) {
                    false -> bots.remove(gid)
                    else -> {}
                }
            }
        }

        ownerTwitch.keys.retainAll(ids)
        ownerYt.keys.retainAll(ids)
        bots.keys.retainAll(ids)
        rebuild()
    }

    @Synchronized
    private fun rebuild() {
        val now = System.currentTimeMillis()
        bots.entries.removeIf { now - it.value.since > 3 * H }
        val merged = HashMap<Long, LiveInfo>()
        merged.putAll(bots)
        merged.putAll(ownerYt)
        merged.putAll(ownerTwitch)

        val sigs = merged.values.map { it.signature }.toSet()
        val newly = merged.values.filter { announced.add(it.signature) }
        announced.retainAll(sigs)

        val changed = live.values.map { it.signature }.toSet() != sigs
        live = merged
        if (changed) onChange?.invoke()
        if (newly.isNotEmpty()) {
            // On the first scan after startup we still notify, but Notifier collapses big batches into one message.
            firstScanDone = true
            onWentLive?.invoke(newly)
        }
    }

    // ---- owner links ------------------------------------------------------------------------------------------

    private fun fetchLinks(ownerId: Long): Links {
        var tw: String? = null
        var yt: String? = null
        var ytName: String? = null
        val arr: JSONArray? = Bridge.profileConnections(ownerId)
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                when (o.optString("type")) {
                    "twitch" -> tw = o.optString("id").takeIf { it.isNotEmpty() }
                    "youtube" -> {
                        yt = o.optString("id").takeIf { it.startsWith("UC") }
                        ytName = o.optString("name")
                    }
                }
            }
        }
        return Links(tw, yt, ytName, System.currentTimeMillis())
    }

    // ---- Twitch Helix -----------------------------------------------------------------------------------------

    private fun helixToken(): String? {
        val now = System.currentTimeMillis()
        token?.let { if (now < tokenExp) return it }
        val body = "client_id=" + URLEncoder.encode(Prefs.twitchClientId.trim(), "UTF-8") +
            "&client_secret=" + URLEncoder.encode(Prefs.twitchClientSecret.trim(), "UTF-8") +
            "&grant_type=client_credentials"
        val r = Net.fetch("POST", "https://id.twitch.tv/oauth2/token", mapOf("Content-Type" to "application/x-www-form-urlencoded"), body)
        if (r == null || !r.ok) return null
        val o = JSONObject(r.body)
        token = o.optString("access_token").takeIf { it.isNotEmpty() }
        tokenExp = now + (o.optLong("expires_in", 3600L) - 120) * 1000
        return token
    }

    /** param is "user_id" or "user_login". Returns map keyed by that same identifier (lower-cased for logins). */
    private fun helixStreams(param: String, values: List<String>): Map<String, JSONObject>? {
        val out = HashMap<String, JSONObject>()
        for (chunk in values.chunked(100)) {
            val tk = helixToken() ?: return null
            val url = "https://api.twitch.tv/helix/streams?first=100&" +
                chunk.joinToString("&") { param + "=" + URLEncoder.encode(it, "UTF-8") }
            val r = Net.fetch("GET", url, mapOf("Client-Id" to Prefs.twitchClientId.trim(), "Authorization" to "Bearer $tk"))
                ?: return null
            if (r.code == 401) {
                token = null
                return null
            }
            if (!r.ok) return null
            val data = JSONObject(r.body).optJSONArray("data") ?: continue
            for (i in 0 until data.length()) {
                val s = data.getJSONObject(i)
                if (s.optString("type") != "live") continue
                out[if (param == "user_id") s.optString("user_id") else s.optString("user_login").lowercase()] = s
            }
        }
        return out
    }

    private fun twitchInfo(guildId: Long, s: JSONObject, viaBot: Boolean) = LiveInfo(
        guildId, Platform.TWITCH, s.optString("user_login"), s.optString("user_name"), s.optString("title"),
        null, s.optInt("viewer_count"), parseIso(s.optString("started_at")), viaBot,
    )

    private fun parseIso(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)!!.time
    } catch (_: Throwable) {
        System.currentTimeMillis()
    }

    // ---- YouTube ----------------------------------------------------------------------------------------------

    /** Reads the `videoDetails` block from a /live or /watch page. Returns null unless it describes a live stream. */
    fun parseYtLive(html: String, guildId: Long): LiveInfo? {
        val at = html.indexOf("\"videoDetails\":{")
        if (at < 0) return null
        val seg = html.substring(at, minOf(html.length, at + 7000))
        if (!seg.contains("\"isLive\":true")) return null
        val id = Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(seg)?.groupValues?.get(1) ?: return null
        fun str(name: String): String {
            val raw = Regex("\"$name\":\"((?:[^\"\\\\]|\\\\.)*)\"").find(seg)?.groupValues?.get(1) ?: return ""
            return runCatching { JSONObject("{\"v\":\"" + raw + "\"}").optString("v") }.getOrDefault(raw)
        }
        val chan = Regex("\"channelId\":\"(UC[A-Za-z0-9_-]{22})\"").find(seg)?.groupValues?.get(1) ?: id
        return LiveInfo(guildId, Platform.YOUTUBE, chan, str("author"), str("title"), id, null, System.currentTimeMillis(), false)
    }

    // ---- bot announcements ------------------------------------------------------------------------------------

    /** Returns true/false when we could check, null when verification isn't possible (then the bot is trusted for 3h). */
    private fun verify(i: LiveInfo): Boolean? = when (i.platform) {
        Platform.TWITCH ->
            if (!Prefs.twitchReady()) null
            else helixStreams("user_login", listOf(i.key))?.let { it.containsKey(i.key.lowercase()) }
        Platform.YOUTUBE -> {
            val html = i.videoId?.let { Net.getText("https://www.youtube.com/watch?v=$it", Net.YT_HEADERS, 3_000_000) }
            if (html == null) null else parseYtLive(html, i.guildId) != null
        }
    }

    fun reportBot(guildId: Long, platform: Platform, key: String, videoId: String?, hint: String) {
        Net.io.execute {
            guard {
                val now = System.currentTimeMillis()
                val base = LiveInfo(guildId, platform, key, key, hint, videoId, null, now, true)
                var info: LiveInfo? = base
                when (platform) {
                    Platform.TWITCH -> if (Prefs.twitchReady()) {
                        val s = helixStreams("user_login", listOf(key))
                        if (s != null) info = s[key.lowercase()]?.let { twitchInfo(guildId, it, true) }
                    }
                    Platform.YOUTUBE -> {
                        val html = Net.getText("https://www.youtube.com/watch?v=$videoId", Net.YT_HEADERS, 3_000_000)
                        if (html != null) info = parseYtLive(html, guildId)?.copy(viaBot = true)
                    }
                }
                if (info != null && bots[guildId]?.signature != info.signature) {
                    bots[guildId] = info
                    rebuild()
                }
            }
        }
    }
}
