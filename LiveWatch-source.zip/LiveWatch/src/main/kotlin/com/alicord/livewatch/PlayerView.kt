package com.alicord.livewatch

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Two modes:
 *  - platform: YouTube /embed or Twitch player in an iframe (their own controls)
 *  - custom:   our HLS player page (quality, speed, gestures, zoom, subtitles + transcript)
 * In custom mode every cross-origin stream request is relayed through shouldInterceptRequest with CORS headers added,
 * because Twitch/YouTube manifests are not meant to be fetched from an arbitrary page origin.
 */
class PlayerView(ctx: Context, private val cb: Callbacks) : FrameLayout(ctx) {
    interface Callbacks {
        fun onFullscreenToggle()
        fun onCustomFailed(msg: String)
    }

    private var web: WebView? = null
    private var customMode = false
    private var fsView: View? = null
    private var fsCb: WebChromeClient.CustomViewCallback? = null
    @Volatile private var released = false

    fun loadPlatform(s: RoomSpec) {
        customMode = false
        val w = fresh(withBridge = false)
        when (s.platform) {
            Platform.YOUTUBE -> w.loadUrl(
                if (s.videoId != null) "https://www.youtube.com/embed/${s.videoId}?autoplay=1&playsinline=1&rel=0"
                else "https://www.youtube.com/embed/live_stream?channel=${s.key}&autoplay=1&playsinline=1&rel=0",
            )
            Platform.TWITCH -> {
                val html = "<html><body style='margin:0;background:#000'><iframe " +
                    "src='https://player.twitch.tv/?channel=${s.key}&parent=localhost&autoplay=true' " +
                    "style='position:fixed;inset:0;width:100%;height:100%;border:0' " +
                    "allow='autoplay; fullscreen' allowfullscreen></iframe></body></html>"
                w.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
            }
        }
    }

    fun loadCustom(s: RoomSpec) {
        customMode = true
        val w = fresh(withBridge = true)
        Net.io.execute {
            try {
                val r = StreamResolver.resolve(s)
                val cfg = JSONObject()
                    .put("src", r.src)
                    .put("live", r.live)
                    .put("title", s.title ?: s.streamer)
                    .put("tracks", JSONArray().also { a -> r.tracks.forEach { a.put(JSONObject().put("label", it.label).put("url", it.url)) } })
                Bridge.ui {
                    if (!released) w.loadDataWithBaseURL("https://alicord.local/", PlayerHtml.build(cfg), "text/html", "utf-8", null)
                }
            } catch (t: Throwable) {
                logw("custom player", t)
                Bridge.ui { if (!released) cb.onCustomFailed(t.message ?: "Could not start the custom player") }
            }
        }
    }

    fun release() {
        released = true
        disposeWeb()
    }

    private fun disposeWeb() {
        fsCb?.onCustomViewHidden()
        hideCustomView()
        web?.let {
            it.stopLoading()
            it.loadUrl("about:blank")
            removeView(it)
            it.removeAllViews()
            it.destroy()
        }
        web = null
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility")
    private fun fresh(withBridge: Boolean): WebView {
        disposeWeb()
        val w = WebView(context)
        w.setBackgroundColor(Color.BLACK)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = Net.UA_MOBILE
        }
        w.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) v.parent?.requestDisallowInterceptTouchEvent(true)
            false
        }
        w.webViewClient = object : WebViewClient() {
            private val allowed = listOf("youtube.com", "youtube-nocookie.com", "twitch.tv", "ttvnw.net", "ytimg.com", "gstatic.com", "google.com", "localhost", "alicord.local")

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: return true
                return allowed.none { host == it || host.endsWith(".$it") } // never navigate away from the player
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (!customMode || request.method != "GET") return null
                val scheme = request.url.scheme ?: return null
                val host = request.url.host ?: return null
                if ((scheme != "https" && scheme != "http") || host == "alicord.local" || host == "cdn.jsdelivr.net") return null
                return try {
                    relay(request)
                } catch (t: Throwable) {
                    logw("relay ${request.url}", t)
                    null
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                fsView = view
                fsCb = callback
                (Bridge.ctx() as? android.app.Activity)?.let { (it.window.decorView as ViewGroup).addView(view, -1, -1) }
            }

            override fun onHideCustomView() = hideCustomView()
        }
        if (withBridge) w.addJavascriptInterface(Js(), "AB")
        addView(w, LayoutParams(-1, -1))
        web = w
        return w
    }

    private fun hideCustomView() {
        fsView?.let { (it.parent as? ViewGroup)?.removeView(it) }
        fsView = null
        fsCb = null
    }

    private fun relay(r: WebResourceRequest): WebResourceResponse {
        val c = URL(r.url.toString()).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 20_000
        c.instanceFollowRedirects = true
        r.requestHeaders.forEach { (k, v) ->
            if (!k.equals("Origin", true) && !k.equals("Referer", true)) c.setRequestProperty(k, v)
        }
        c.setRequestProperty("User-Agent", Net.UA_MOBILE)
        val code = c.responseCode.let { if (it in 300..399) 502 else it }
        val ct = c.contentType ?: guessMime(r.url.path ?: "")
        val mime = ct.substringBefore(';').trim().ifEmpty { "application/octet-stream" }
        val enc = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
        val headers = hashMapOf("Access-Control-Allow-Origin" to "*", "Access-Control-Expose-Headers" to "*")
        for ((k, v) in c.headerFields) {
            if (k != null && k.lowercase() in setOf("content-range", "accept-ranges", "content-length")) headers[k] = v.joinToString()
        }
        val stream = if (code >= 400) c.errorStream else c.inputStream
        return WebResourceResponse(mime, enc, code, c.responseMessage?.ifEmpty { null } ?: "OK", headers, stream)
    }

    private fun guessMime(path: String) = when {
        path.endsWith(".m3u8") -> "application/vnd.apple.mpegurl"
        path.endsWith(".ts") -> "video/mp2t"
        path.endsWith(".vtt") -> "text/vtt"
        path.endsWith(".mp4") || path.endsWith(".m4s") -> "video/mp4"
        path.endsWith(".aac") -> "audio/aac"
        else -> "application/octet-stream"
    }

    inner class Js {
        @JavascriptInterface fun lock(on: Boolean) {
            post { this@PlayerView.parent?.requestDisallowInterceptTouchEvent(on) }
        }

        @JavascriptInterface fun copy(text: String) {
            post {
                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("transcript", text))
            }
        }

        @JavascriptInterface fun fullscreen() {
            post { cb.onFullscreenToggle() }
        }

        @JavascriptInterface fun failed(msg: String) {
            post { cb.onCustomFailed(msg) }
        }
    }
}
