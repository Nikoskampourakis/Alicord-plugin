package com.alicord.livewatch

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import java.util.WeakHashMap

/** The "you're live" ring + LIVE pill drawn over a server icon, like the live ring on YouTube avatars. */
class LiveRingDrawable(private val color: Int, private val rounded: Boolean, pulse: Boolean) : Drawable() {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2.5f); color = this@LiveRingDrawable.color }
    private val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFED4245.toInt() }
    private val pillEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1.5f); color = 0xFF1E1F22.toInt() }
    private val pillText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = dp(8f); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private var phase = 1f
    private val anim: ValueAnimator? = if (pulse) ValueAnimator.ofFloat(0.55f, 1f).apply {
        duration = 1100; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase = it.animatedValue as Float; invalidateSelf() }
    } else null

    fun start() { anim?.let { if (!it.isStarted) it.start() } }
    fun stop() { anim?.cancel() }

    override fun draw(c: Canvas) {
        val b = bounds
        val r = RectF(b).apply { inset(dp(4f), dp(4f)) }
        ring.alpha = (255 * phase).toInt()
        if (rounded) c.drawRoundRect(r, dp(14f), dp(14f), ring) else c.drawOval(r, ring)

        val w = pillText.measureText("LIVE") + dp(8f)
        val h = dp(12f)
        val pill = RectF(r.centerX() - w / 2, r.bottom - h / 2, r.centerX() + w / 2, r.bottom + h / 2)
        c.drawRoundRect(pill, h / 2, h / 2, pillBg)
        c.drawRoundRect(pill, h / 2, h / 2, pillEdge)
        c.drawText("LIVE", pill.centerX(), pill.centerY() - (pillText.ascent() + pillText.descent()) / 2, pillText)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

object LiveRing {
    private val rings = WeakHashMap<View, LiveRingDrawable>()
    private val watched = WeakHashMap<View, Boolean>()

    fun apply(view: View, info: LiveInfo) {
        clear(view)
        val d = LiveRingDrawable(info.platform.color, Prefs.roundedRing, Prefs.pulse)
        rings[view] = d
        view.foreground = d
        if (watched.put(view, true) == null) {
            view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) { rings[v]?.start() }
                override fun onViewDetachedFromWindow(v: View) { rings[v]?.stop() }
            })
        }
        if (view.isAttachedToWindow) d.start()
    }

    fun clearAll() {
        rings.keys.toList().forEach { clear(it) }
    }

    fun clear(view: View) {
        rings.remove(view)?.let {
            it.stop()
            if (view.foreground === it) view.foreground = null
        }
    }
}
