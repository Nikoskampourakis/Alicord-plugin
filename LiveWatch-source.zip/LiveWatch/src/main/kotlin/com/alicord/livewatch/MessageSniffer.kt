package com.alicord.livewatch

/** Looks at incoming messages for (a) live announcements from bots/webhooks and (b) Watch Party invite codes in DMs. */
object MessageSniffer {
    private val TWITCH_URL = Regex("https?://(?:www\\.|m\\.)?twitch\\.tv/([A-Za-z0-9_]{3,25})(?![A-Za-z0-9_/])")
    private val YT_URL = Regex("(?:youtube\\.com/(?:watch\\?v=|live/)|youtu\\.be/)([A-Za-z0-9_-]{11})")
    private val LIVE_CUE = Regex("\\b(live|streaming|went live|now live|stream)\\b", RegexOption.IGNORE_CASE)
    private val RESERVED = setOf("directory", "videos", "settings", "downloads", "jobs", "turbo", "store", "p", "login", "signup")

    fun onMessage(m: Any) {
        try {
            val content = m.strFld("content") ?: ""
            val channelId = m.longFld("channelId") ?: return
            val guildId = m.longFld("guildId")
            val author = m.fld("author")
            val authorId = author?.longFld("id")

            if (guildId == null) {
                if (Prefs.inviteDetection && authorId != null && authorId != Bridge.meId()) invite(content, channelId, author?.strFld("username"))
                return
            }
            val isBot = (author?.fld("bot") as? Boolean) == true || m.fld("webhookId") != null
            if (isBot && Prefs.botDetection && Prefs.tracks(guildId)) liveAnnouncement(m, content, guildId)
        } catch (t: Throwable) {
            logw("sniffer", t)
        }
    }

    private fun invite(content: String, channelId: Long, from: String?) {
        val spec = RoomSpec.fromCode(content, fallbackChannel = channelId) ?: return
        Bridge.notify("${from ?: "A friend"} invited you to watch", "${spec.streamer} on ${spec.platform.label} — tap to join") {
            WatchRoom.open(spec)
        }
    }

    private fun liveAnnouncement(m: Any, content: String, guildId: Long) {
        val sb = StringBuilder(content)
        (m.fld("embeds") as? List<*>)?.forEach { e ->
            if (e == null) return@forEach
            listOf("url", "title", "description").forEach { f -> e.strFld(f)?.let { sb.append('\n').append(it) } }
            e.fld("author")?.let { a -> a.strFld("name")?.let { sb.append('\n').append(it) }; a.strFld("url")?.let { sb.append('\n').append(it) } }
        }
        val text = sb.toString()
        if (!LIVE_CUE.containsMatchIn(text)) return
        val hint = text.lineSequence().firstOrNull { it.isNotBlank() && !it.startsWith("http") }?.take(100) ?: ""

        TWITCH_URL.find(text)?.groupValues?.get(1)?.takeIf { it.lowercase() !in RESERVED }?.let {
            return LiveDetector.reportBot(guildId, Platform.TWITCH, it, null, hint)
        }
        YT_URL.find(text)?.groupValues?.get(1)?.let {
            LiveDetector.reportBot(guildId, Platform.YOUTUBE, it, it, hint)
        }
    }
}
