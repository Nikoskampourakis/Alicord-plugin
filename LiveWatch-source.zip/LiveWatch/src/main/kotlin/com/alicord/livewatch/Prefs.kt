package com.alicord.livewatch

import com.aliucord.api.SettingsAPI
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

object Prefs {
    private lateinit var s: SettingsAPI
    fun init(api: SettingsAPI) {
        s = api
    }

    private fun bool(key: String, def: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = s.getBool(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) = s.setBool(key, value)
    }

    private fun str(key: String, def: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = s.getString(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) = s.setString(key, value)
    }

    var notifyLive by bool("notifyLive", true)
    var ring by bool("ring", true)
    var pulse by bool("pulse", true)
    var roundedRing by bool("roundedRing", false)
    var botDetection by bool("botDetection", true)
    var inviteDetection by bool("inviteDetection", true)
    var trackAll by bool("trackAll", true)

    /** room | ask | server — what tapping a live server icon does */
    var tapAction by str("tapAction", "room")

    /** platform | custom — which player the Watch Room opens with */
    var defaultPlayer by str("defaultPlayer", "platform")

    var trackedIds by str("trackedIds", "")
    var twitchClientId by str("twitchClientId", "")
    var twitchClientSecret by str("twitchClientSecret", "")
    var pollSecondsRaw by str("pollSeconds", "120")

    val pollSeconds: Int get() = (pollSecondsRaw.toIntOrNull() ?: 120).coerceIn(60, 900)

    fun twitchReady() = twitchClientId.isNotBlank() && twitchClientSecret.isNotBlank()

    fun tracks(guildId: Long): Boolean =
        trackAll || trackedIds.split(',', ' ', '\n').any { it.trim() == guildId.toString() }
}
