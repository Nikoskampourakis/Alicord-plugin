version = "1.0.0"
description = "Get notified when server owners go live on Twitch/YouTube, see a live ring on the server icon, and watch together in a virtual room."

aliucord {
    changelog.set("""
        # 1.0.0
        * Live detection for server owners (Twitch + YouTube) and live-announcement bots
        * Live ring on server icons, tap to enter the Watch Room
        * Platform player or custom HLS player (quality, speed, gestures, zoom, subtitles + transcript)
        * Watch parties via invite code, with chat/voice in the shared Discord channel
    """.trimIndent())
}
